package mx.edu.itson.examenc1

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val tipoPoliza: EditText = findViewById(R.id.etTipoPoliza)
        var costo: TextView = findViewById(R.id.tvCosto)
        val años: EditText = findViewById(R.id.etAños)
        val pagar: TextView = findViewById(R.id.tvPagar)
        tipoPoliza.setOnClickListener {
            val tipoOriginal = tipoPoliza.text.toString()
            val tipo = tipoOriginal.lowercase()
            var costoFinal:Double=0.0
            if (tipo.equals("autos sedan")) {
                costoFinal=500.0
            }else if (tipo.equals("camionetas")) {
                costoFinal=700.0
            }else if (tipo.equals("autos deportivos")) {
                costoFinal=1200.0
            }else{
                costo.text="Escribe un tipo de poliza correcto"
            return@setOnClickListener
            }
            costo.text= costoFinal.toString()
            años.setText("0")
            pagar.text=""
        }
        años.setOnClickListener{
            if (años.text.toString().toDouble()==0.0){
                    pagar.text="Escribe un año mayor a 0"

            }else{
                var precio:Double=(costo.text.toString().toDouble() *años.text.toString().toDouble())
                pagar.text="Pagar $"+precio.toString()
            }
        }

    }
}